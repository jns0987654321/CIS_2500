#include <stdio.h>
#include <stdlib.h>

void change(int var1, int *var2)
{
	var1=5;
	*var2=5;
}

int main (void) 
{
	int var1=3, var2=3;
	
	change(var1, &var2);
	
	printf("%d  %d\n", var1, var2);
	
	
    return 0;
}

#include <stdio.h>
#include <stdlib.h>

void f1(int *j);
void f2(int *k);

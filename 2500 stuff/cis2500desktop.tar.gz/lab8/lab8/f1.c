#include "labhead.h"

void f1(int *j)
{
	f2(j);
}

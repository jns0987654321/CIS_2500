#include "labhead.h"

void f2(int *k)
{
	*k=10;
}

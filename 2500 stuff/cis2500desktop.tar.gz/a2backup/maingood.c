#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>


void isSentence(char ch, int *Alpha, int *SentChk, int *punct, int *Words, int *totalSents, int *onlyVowel_e);
void isSyllable(char ch, int *isVowel, int *vowelChk, int *syllables, int *Vowel_e, int *onlyVowel_e, int *endVowel_e);


int main (void) 
{
	int Alpha=0;
	int SentChk=0;
	int punct=0;
	int Words=0;
	int totalSents=0;
	int onlyVowel_e=0;
	int isVowel=0;
	int vowelChk=0;
	int syllables=0;
	int Vowel_e=0;
	int endVowel_e=0;
	int totalSylls=0;
	int totalWords=0;
	int index;
	char ch;
	
	while ((ch = getchar()) != EOF)
	{			

		isSentence(ch, &Alpha, &SentChk, &punct, &Words, &totalSents, &onlyVowel_e);
		
		isSyllable(ch, &isVowel, &vowelChk, &syllables, &Vowel_e, &onlyVowel_e, &endVowel_e);
		
	}
	
	totalWords=Words+totalSents;
	totalSylls=syllables-endVowel_e;
	
	index= floor(206.835 - 84.6 * ((float)totalSylls/(float)totalWords) - 1.015 * ((float)totalWords/(float)totalSents)+0.5);
	
	printf("\nLegibility Index = %d", index);
	printf("\nSyllable count   = %d", totalSylls);
	printf("\nWord count       = %d", totalWords);
	printf("\nSentence count   = %d\n", totalSents);
	
    return 0;
	
}


void isSyllable(char ch, int *isVowel, int *vowelChk, int *syllables, int *Vowel_e, int *onlyVowel_e, int *endVowel_e)
{
	if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' || ch=='y')
	{
		*isVowel=1;
	}
	else
	{
		*isVowel=0;
	}

	if(*isVowel==1)
	{
		*vowelChk=*vowelChk+1;
	}
	
	
	if((*isVowel==0 && *vowelChk>=1) && (isalpha(ch) || isspace(ch)))
	{
		*syllables=*syllables+1;
		*vowelChk=0;
	}
	
	
	if((*Vowel_e==1) && ((isspace(ch)) || (ch=='.')))
	{
		
		if(*onlyVowel_e > 1)
		{
			*endVowel_e=*endVowel_e+1;
		}
		
		*onlyVowel_e=0;
		*Vowel_e=0;
	}
	
	
	if(ch=='e')
	{
		*Vowel_e=*Vowel_e+1;
		*onlyVowel_e=*onlyVowel_e+1;
	}
	else
	{
		*Vowel_e=0;
	}
	
}



void isSentence(char ch, int *Alpha, int *SentChk, int *punct, int *Words, int *totalSents, int *onlyVowel_e)
{
	if(isalpha(ch))
	{
		*Alpha=1;
		*SentChk=1;
	}
	
	
	if(ch=='.' || ch==':' || ch==';' || ch=='?' || ch=='!')
	{
		*punct=*punct+1;
		
		if (*punct>=1 && (ch=='.' || ch==':' || ch==';' || ch=='?' || ch=='!'))
		{
			*Words=*Words-1;
			*punct=0;
		}
	}
	
	
	if(ispunct(ch))
	{
		*Alpha=1;
	}
	
	
	if((ch=='.' || ch==':' || ch==';' || ch=='?' || ch=='!') && *SentChk==1)
	{
		*totalSents=*totalSents+1;
		*SentChk=0;
		*onlyVowel_e =0;
	}
	
	
	if(((ch==' ') || ch=='\n' || ch=='.') && (*Alpha==1))
	{
		*Words=*Words+1;
		*Alpha =0;
	}		
	
}





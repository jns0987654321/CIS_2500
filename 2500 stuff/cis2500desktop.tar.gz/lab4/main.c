#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <math.h>

int isvowel(int c)
{
	switch (c){
		case 'a': ;
		case 'e': ;
		case 'i': ;
		case 'o': ;
		case 'u': ;
		case 'y': return 1;
			break;
		default : return 0;
	}
}

int main (void) 
{
	int alpha=0;
	int x=0;
	int word=0;
	int sent=0;
	int beta=0;
	int gamma=0;
	int vowel=0;
	int vowel2=0;
	int vowel3=0;
	int vowel4=0;
	int vowel5=0;
	int vowele=0;
	int ve=0;
	int vee=0;
	int spw=0;
	int syllables=0;
	int totalWords=0;
	int index;
	char ch;
	while ((ch = getchar()) != EOF)
	{			

		if(isalpha(ch)){
			alpha=1;
			beta=1;}
		
		if(ch=='.'){
			gamma++;
		if (gamma>=1 && ch=='.') {
			word--;
			gamma=0;}
		}
		
		if(ispunct(ch)){
			alpha=1;}
		
		if(ch=='.' && beta==1){
			sent=sent+1;
			beta=0;
			vowel4 =0;
		}
		
		if(((ch==' ') || ch=='\n' || ch=='.') && (alpha==1)){
			word=word+1;
			alpha =0;}
		
		

		x=isvowel(ch);
		
		if(x==1){
			vowel++;
			vowel2++;
			vowel5++;}
		
		if((x==0 && vowel2>=1) && (isalpha(ch) || isspace(ch))){
			vowel3++;
			spw++;
			vowel2=0;}
		
		if((vowele==1) && ((isspace(ch)) || (ch=='.'))){
			ve++;
			if(vowel4 > 1){
				vee++;}
			vowel4=0;
			vowele=0;
		}
		
		if(ch=='e'){
			vowele++;
			vowel4++;}
		else {
			vowele=0;}
		
		
		
		
		//printf("\n%c  %d  %d\n", ch, vee, vowel4);
	}
	
	totalWords=word+sent;
	syllables=vowel3-vee;
	
	//index= floor((206.835) - (84.6) ((float)syllables/(float)totalWords)*((float)totalWords/(float)sent));
	
	printf("\n%d", word);
	printf("\n%d", sent);
	printf("\n%d", vowel3);
	printf("\n%d", vowel4);
	printf("\n%d", spw);
	printf("\n%d", vee);
	printf("\n%d\n", index);
	
    return 0;
	
}

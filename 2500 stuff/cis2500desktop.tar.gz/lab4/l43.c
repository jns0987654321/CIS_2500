#include <stdio.h>
#include <stdlib.h>
#include <string.h>


struct part			/* Structure definition */
{
	char name[30];
	int number;
	float cost;
};

struct part *function()		/* Function that dynamically allocates structure */
{
	struct part *ptr;	/* Declaration of dynamic structure */
	ptr = malloc(sizeof(struct part));
	ptr ->number = 4;
	ptr ->cost = 44.4;
	strcpy(ptr->name, "john");
	
	return ptr;		/* Returns pointer to the defined strucutre in main */
}

int main (void) 
{
	struct part *ptr;	/* Declaration of dynamic strucutre */
	ptr = function();	/* Function that is called to allocate structure */
	
	/* Output of values stored in structure */
	printf("\ndynamic name is %s \ndynamic number is %d \ndynamic cost is %.1lf \n", ptr->name, ptr->number, ptr->cost);
	
    	return 0;
}


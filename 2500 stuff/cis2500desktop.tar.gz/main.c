#include "labhead.h"

int main (void)
{
	int i;
	f1(&i);
	printf("\n%d\n", i);
	
	return 0;
}

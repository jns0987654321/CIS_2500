#include "add.h"

int main(void)
{
	int num1=5;
	int num2=3;
	int result;

	result=add(num1, num2);
	printf("\nresult = %d\n", result);

	return 0;

}


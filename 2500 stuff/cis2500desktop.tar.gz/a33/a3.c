/* Junior Samaroo     0663108 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

/* Structure being written to disk */
typedef struct employeeRecord
{
	char *name;
	char *address;
	short addressLength, nameLength;
	int phoneNumber;
}records;

void CreateRecord(records *ptr, FILE *fp, records *tempStruct, char *nameString, char *addressString); /* Function that writes a new record to disk */
void RetriveByName(FILE *fp, int *maxFileSize, records *tempStruct, char *nameString, char *addressString, char tempName[51]); /* Function that retrieves record info by name entered */
void RetriveByNum(int i, int *recordNum, records *tempStruct, FILE *fp, int *currentFileSize, int *maxFileSize, char *nameString, char *addressString);/*Retrieves info by record number*/
void FreeAndExit(int *choices, char *nameString, char *addressString, int *isAllocated, records *ptr); /* Function that frees memory and exits program */

int main (void)
{	
	FILE *fp; /* File pointer */
	int ch=0; /* User menu choice input */
	int i; /* Loop index */
	int choices=0; /* Counts choices selected by user */
	int isAllocated; /* Checks if memory is allocated */
	int maxFileSize; /* Max size of file */
	int recordNum; /* Record number to search for */
	int currentFileSize; /* Current size of file pointed by ftell() */
	records *ptr; /* Pointer to structure */
	records tempStruct; /* Temporary strucuture */
	char *nameString; /* Stores name string for record */
	char *addressString; /* Stores address string for record */
	char tempName[51]; /* Stores the name to search for record by name */
	
	while(ch==0) 
	{
		if (ch==0) /* Loop that checks user choice and returns back to menu */
		{
			printf("\n1. Enter a new record. \n");
			printf("2. Retrieve a record by name. \n");
			printf("3. Retrieve a record by number. \n");
			printf("4. Exit \n");
			printf("Enter a number from 1-4: ");
			scanf("%d", &ch);
			fflush(stdin);
		}
		
		if (ch==1) /* Allows user to enter new record */
		{	
			getchar();
			fp = fopen("employeeRecords", "ab+"); /* Opens file for appending data, creates the file if it does not exist */
			
			ptr = malloc(sizeof(records));	/* Allocates memory for pointer */
			ptr->name = malloc(sizeof(char));
			nameString = malloc(sizeof(char)*tempStruct.nameLength);
			
			printf("\nEnter the name:\n "); /* Enters name to store in file */
			fgets(nameString, 100, stdin);
			fflush(stdin);
			strcpy(ptr->name, nameString);
			ptr->nameLength = strlen(ptr->name)+1;
			
			ptr->address = malloc(sizeof(char));
			addressString = malloc(sizeof(char)*tempStruct.addressLength);
			printf("Enter the address:\n "); /* Enters address to store in file */
			fgets(addressString, 100, stdin);
			fflush(stdin);
			strcpy(ptr->address, addressString);
			ptr->addressLength = strlen(ptr->address)+1;
			
			printf("Enter the phone number:\n "); /* Enters phone number to store in file */
			scanf("%d", &ptr->phoneNumber);
			fflush(stdin);
			
			CreateRecord(ptr, fp, &tempStruct, nameString, addressString); /* Calls the CreateRecord function */
			
			printf("\nRecord Stored Successfully!!\n");
			
			fclose(fp);
			choices=choices+1;
			isAllocated=1; /* 'Ptr' is allocated so it can be freed */
			ch=0;
		}
		
		if (ch==2) /* Allows user to retrieve record by name */
		{
			getchar();
			
			printf("\nEnter a name: "); /* User enters name to find */
			fgets(tempName, 51, stdin);
			fflush(stdin);
			
			fp = fopen("employeeRecords", "r+");
			fseek(fp, 0L, SEEK_END);
			maxFileSize = ftell(fp); /* Finds "end of file" */
			fseek(fp, 0L, SEEK_SET);
			
			RetriveByName(fp, &maxFileSize, &tempStruct, nameString, addressString, tempName); /* Calls the RetrieveByName function */
			
			fclose(fp);
			choices=choices+1;
			ch=0;
		}
		
		if (ch==3) /* Allows user to retrieve record by record number */
		{
			getchar();
			
			printf("\nEnter a record number: \n"); /* User enters record number to find */
			scanf("%d", &recordNum);
			fflush(stdin);
			
			fp = fopen("employeeRecords", "r");
			fseek(fp, 0L, SEEK_END);
			maxFileSize = ftell(fp);
			fseek(fp, 0L, SEEK_SET);
			
			RetriveByNum(i, &recordNum, &tempStruct, fp, &currentFileSize, &maxFileSize, nameString, addressString); /* Calls the RetrieveByNum function */
			
			fclose(fp);
			choices=choices+1;
			ch=0;
		}
	}
	
	FreeAndExit(&choices, nameString, addressString, &isAllocated, ptr); /* Calls the FreeAndExit function */
	
    return 0;
}


void CreateRecord(records *ptr, FILE *fp, records *tempStruct, char *nameString, char *addressString)
{
	/* Writes record information to binary file on disk */
	fwrite(ptr, sizeof(records), 1, fp);
	fseek(fp, -sizeof(records), SEEK_CUR);
	fread(tempStruct, sizeof(records), 1, fp);
	fwrite(nameString, sizeof(char)*tempStruct->nameLength, 1, fp);
	fwrite(addressString, sizeof(char)*tempStruct->addressLength, 1, fp);
}


void RetriveByName(FILE *fp, int *maxFileSize, records *tempStruct, char *nameString, char *addressString, char tempName[51])
{
	while (ftell(fp)!=*maxFileSize) /* Loop that reads the structures to find the name entered */
	{
		fread(tempStruct, sizeof(records), 1, fp);	
		nameString = malloc(sizeof(char)*tempStruct->nameLength);
		addressString = malloc(sizeof(char)*tempStruct->addressLength);
		fread(nameString, sizeof(char)*tempStruct->nameLength, 1, fp);
		fread(addressString, sizeof(char)*tempStruct->addressLength, 1, fp);
		
		if ((strcmp(nameString, tempName)==0)) /* Prints record info only if name entered was found */
		{
			printf("\nMATCH FOUND!!\n");
			printf("Name: %s", nameString);
			printf("Address: %s", addressString);
			printf("Telephone Number: %d\n", tempStruct->phoneNumber);
			break;	
		}
	}
	
	if ((ftell(fp)==*maxFileSize) && (strcmp(nameString, tempName)!=0)) 
	{
		printf("\nRECORD NOT FOUND!!\n");
	}	

}


void RetriveByNum(int i, int *recordNum, records *tempStruct, FILE *fp, int *currentFileSize, int *maxFileSize, char *nameString, char *addressString)
{
	for (i=0; i<*recordNum; i++) /* Loop that seeks from the beginning of file to location user entered to retrieve record info */
	{
		fread(tempStruct, sizeof(records), 1, fp);	
		fseek(fp, +tempStruct->nameLength+tempStruct->addressLength, SEEK_CUR); /* Seeks past string lengths */
	}
	
	*currentFileSize=ftell(fp);
	
	if (*currentFileSize<*maxFileSize) /* Loop that retrieves record info only if the number entered is valid */
	{
		fread(tempStruct, sizeof(records), 1, fp);		
		nameString = malloc(sizeof(char)*tempStruct->nameLength);
		addressString = malloc(sizeof(char)*tempStruct->addressLength);
		fread(nameString, sizeof(char)*tempStruct->nameLength, 1, fp);
		fread(addressString, sizeof(char)*tempStruct->addressLength, 1, fp);
		
		printf("\nName: %s", nameString);
		printf("Address: %s", addressString);
		printf("Telephone Number: %d\n", tempStruct->phoneNumber);
		
	}else 
		printf("\nRecord not available, number too large!!\n");	
	
}


void FreeAndExit(int *choices, char *nameString, char *addressString, int *isAllocated, records *ptr)
{
	if (*choices>=1) 
	{
		nameString=NULL;
		addressString=NULL;
		
		if (*isAllocated==1) /* Frees pointers only if memory is allocated */
		{
			free(ptr->name);
			free(ptr->address);
			free(ptr);
		}
	}		
}

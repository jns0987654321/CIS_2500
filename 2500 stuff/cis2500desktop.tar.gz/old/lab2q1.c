/* Junior Samaroo     (Student# 0663108) */

#include <stdio.h>

int main (void)
{
	int i;         // Row index counter
	int j;         // Column index counter
	int x;         // Number of rows
	int y;	       // Number of columns
	
	// Input of rows and columns
	printf("Enter # of rows:");
	scanf("%d", &x);
	printf("Enter # of columns:");
	scanf("%d", &y);
	int array[x][y];
	
	// Sum of indices of rows and columns
	for (i = 0; i < x; i++)
	{
		for (j = 0; j < y; j++)
		array[i][j] = i + j + 2;
	}
	
	// Print contents of array
	for (i = 0; i < x; i++)
	{
		for ( j = 0; j < y; j++ )
		printf( "%d ", array[i][j] );
		printf( "\n" );
	}
	
    return 0;

}

/* Junior Samaroo     (Student# 0663108) */

#include <stdio.h>

int main (void)
{
	int i;         /* Row index counter */
	int j;         /* Column index counter */
	int x;         /* Number of rows */
	int y;	       /* Number of columns */
	
	/* Input of rows and columns */
	printf("Enter # of rows:");
	scanf("%d", &x);
	printf("Enter # of columns:");
	scanf("%d", &y);
	int array[x][y];
	

	/* Sum of indices of rows and columns */
	for (i = 1; i < x+1; i++)
	{
		for (j = 1; j < y+1; j++)
		array[i][j] = i + j;
	}
	
	/* Print contents of array */
	for (i = 1; i < x+1; i++)
	{
		for ( j = 1; j < y+1; j++ )
		printf( "%d ", array[i][j] );
		printf( "\n" );
	}
	
    return 0;

}

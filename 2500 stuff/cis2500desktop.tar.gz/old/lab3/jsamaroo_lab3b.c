#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main (void) 
{
    int size;				/* Number of strings to enter*/
    int i=0;				/* Loop index */
    char string[26];			/* Character array to store string*/
    char **array;
	
    scanf("%d", &size);			/* Assigns to size the number of strings the user wishes to enter*/
	
    array = malloc(sizeof(char*)*size);	/* Creates a dynamically allocated array of the size of the number of strings */
		
    /* Loop to allocate memory to each elememt of array*/
    for(i = 0; i<size; i++)
    {
	array[i] = malloc(sizeof(char)*26);
	scanf("%s", string);
        strcpy(array[i], string);	/* Copies the string into the array*/
    }
	/* Loop to print each string on new line */
	for(i=0; i<size; i++)
	{
	    printf("%s", array[i]);
	    printf("\n");
	}
	
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main (void) 
{
    srand( time(NULL) );			/* Seed from computer's time*/
    int i, j;					/* Loop index */
    int **array =  malloc(sizeof(int*)*5);	/* Dynamically allocates 2D array of intergers*/
	
    /* Loop that allocates memory to each element in thearray*/
    for(i = 0; i<5 ; i++)
    {
	array[i] =  malloc(sizeof(int)*5);

	for (j = 0; j < 5; j++)
	{
	    array[i][j] = rand() %99+1;		/* Assigns a random number to an element in the array*/
	    printf("%3d ", array[i][j]);

	    if (j==4)
	        printf("\n");
	}
    }

    return 0;
}

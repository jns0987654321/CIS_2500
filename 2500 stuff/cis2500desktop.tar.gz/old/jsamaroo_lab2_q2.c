/* Junior Samaroo     (Student# 0663108) */

#include <stdio.h>
#include <math.h>

int main (void)
{
	int i;
	int high=0;          /* Highest number */
	int high_i;          /* Highest number index value */
	int array[10];       /* Array of 10 numbers */
	
	/* Input */
	printf("Enter each number and press enter:\n");
	for(i=0; i<=9; i++)
	scanf("%d", &array[i]);
	
	/* Finding highest number in array */
	for(i=0; i<=9; i++)
	{
		if (array[i] > high)
		{
			high=array[i];
			high_i=i;
		}
	}
	
	/* Rearrangement of array */
	for(i=high_i-1; i>=0; i--)
		array[i+1] = array[i];
	
	array[0]=high;
	
	/* Output of new array */
	for(i=0; i<=9; i++)
		printf("%d ", array[i]);
	
	return 0;
}


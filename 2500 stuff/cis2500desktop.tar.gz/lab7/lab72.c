/* Junior Samaroo      0663108 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct data{
	int count;
	double total;
}info;

int main(void)
{
	FILE *fp;
	int i, size;
	info str[10];
	info str2;
	/* Write 10 structures to binary file */
	fp=fopen("infodata", "a+");
	for(i=0; i<10; i++)
	{
		str[i].count = i;
		str[i].total = i*2;
		fwrite(&str[i], sizeof(info), 1, fp);
	}
	
	/* Seeks to 3th record in file */
	fseek(fp, sizeof(info)*2, SEEK_SET);
	size = ftell(fp);
	printf("\nftell= %d", size);
	fread(&str2, sizeof(info), 1, fp);
	printf("\ncount[3]= %d    total[3]= %lf \n", str2.count, str2.total);
	
	/* Seeks to 7th record in file */
	fseek(fp, sizeof(info)*6, SEEK_SET);
	size = ftell(fp);
	printf("\nftell= %d", size);
	fread(&str2, sizeof(info), 1, fp);
	printf("\ncount[7]= %d    total[7]= %lf \n", str2.count, str2.total);
	
	fclose(fp);
	
	return(0);
	
}
